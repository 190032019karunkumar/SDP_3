package net.codejava;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TechniquesRepository extends JpaRepository<Techniques, Long> {

}